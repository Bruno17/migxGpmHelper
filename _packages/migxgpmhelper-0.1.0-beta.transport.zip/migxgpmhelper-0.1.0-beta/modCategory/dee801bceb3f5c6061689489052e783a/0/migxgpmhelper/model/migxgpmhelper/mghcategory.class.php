<?php
class mghCategory extends xPDOSimpleObject {}