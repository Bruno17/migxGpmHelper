<?php
class mghPackage extends xPDOSimpleObject {}