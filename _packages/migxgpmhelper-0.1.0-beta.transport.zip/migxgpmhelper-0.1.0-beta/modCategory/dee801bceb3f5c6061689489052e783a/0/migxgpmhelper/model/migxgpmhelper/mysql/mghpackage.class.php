<?php
require_once (dirname(__DIR__) . '/mghpackage.class.php');
class mghPackage_mysql extends mghPackage {}