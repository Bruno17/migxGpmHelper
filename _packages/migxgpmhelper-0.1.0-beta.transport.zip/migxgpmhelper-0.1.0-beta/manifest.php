<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '91809d302b455314eb346709a1aefc67',
      'native_key' => 'migxgpmhelper',
      'filename' => 'modNamespace/bba2f5cf8cc05d85f8e416a49272a333.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '96f7177294c59bf674229a4e89741908',
      'native_key' => NULL,
      'filename' => 'modCategory/dee801bceb3f5c6061689489052e783a.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
  ),
);