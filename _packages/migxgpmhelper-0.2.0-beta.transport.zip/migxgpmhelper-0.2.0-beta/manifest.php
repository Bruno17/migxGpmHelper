<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a5d4c79b02fe014366847ec3ab8f444a',
      'native_key' => 'migxgpmhelper',
      'filename' => 'modNamespace/8f535cab42bfda1a6e6d88254606230c.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ad16db7270710d5213610dc3c9f91732',
      'native_key' => NULL,
      'filename' => 'modCategory/07f23fe7e31a3cd39d4fa71b8393f405.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '429657e472ee1b4f782d846ad943c9ed',
      'native_key' => 'migxGpmHelper',
      'filename' => 'modMenu/24cee88ba870cdaa2ddb8f11168b11de.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
  ),
);