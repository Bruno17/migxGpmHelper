<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d2bb70ebdc0be0b6ae5f473e2eb3cd4',
      'native_key' => 'migxgpmhelper',
      'filename' => 'modNamespace/75204a2b59699613c0430b27f6adbac9.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6ae017f829542032b54d8db870e829a2',
      'native_key' => NULL,
      'filename' => 'modCategory/ec7319a033071309171ea5e61358406b.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '890477b806c7ca0003efdc52f9076f6e',
      'native_key' => 'migxGpmHelper',
      'filename' => 'modMenu/5e93a9295dda08fff2ea8183879c1684.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
  ),
);