<?php
require_once (dirname(__DIR__) . '/mghcategory.class.php');
class mghCategory_mysql extends mghCategory {}