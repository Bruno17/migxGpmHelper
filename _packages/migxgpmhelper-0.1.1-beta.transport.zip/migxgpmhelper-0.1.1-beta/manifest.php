<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd9d5da5f867d7f86fd5d64716efe68cf',
      'native_key' => 'migxgpmhelper',
      'filename' => 'modNamespace/c9e6717af16059bcba6543e14a180eb4.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd3e332bb4f5dbd0f4401660bea6e6c10',
      'native_key' => NULL,
      'filename' => 'modCategory/2943d7b06e9d2871637c74a574c33a2f.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5f5d6e1b69d93cf4c09c72822dd5dfd1',
      'native_key' => 'migxGpmHelper',
      'filename' => 'modMenu/d3e890d1f4ccf94c5828dd5cc59425c2.vehicle',
      'namespace' => 'migxgpmhelper',
    ),
  ),
);